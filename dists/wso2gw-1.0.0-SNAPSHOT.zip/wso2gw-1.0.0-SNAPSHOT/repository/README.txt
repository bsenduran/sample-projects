$CARBON_HOME/repository is the main repository for all kind of deployments and
configurations in Carbon. This includes all Runtime related artifacts. In
addition to that, Carbon configurations are also hosted under this folder.

1. deployment
   Directory can be used to deploy artifacts on carbon kernel based server.
   See deployment/README for more details.

2. conf
   Directory contains all the configuration files. eg: carbon.xml.

3. components
   Directory contains all OSGi related stuff. Carbon bundles, OSGi configuration
   files and p2 stuff. See components/README for more details.

4. logs
   Directory contains all Carbon logs.
