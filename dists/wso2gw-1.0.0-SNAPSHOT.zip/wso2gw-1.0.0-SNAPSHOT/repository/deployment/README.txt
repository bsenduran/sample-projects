This directory can be used to deploy all kind of deployable artifacts in Carbon.
The 'server' directory is the place to deploy all your artifacts.

You can have any directories inside the 'server' folder, based on the registered deployer it belongs

Eg :
dataservices - for data service deployment
webapps - Directory used for hosting webapps
