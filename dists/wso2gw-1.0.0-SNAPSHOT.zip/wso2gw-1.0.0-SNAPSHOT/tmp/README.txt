CARBON_HOME/tmp Used for storing temporary files, and is pointed to by the
java.io.tmpdir System property

1. work
   Directory where Carbon may store various files. This directory will be
   periodically cleaned up by the Carbon Housekeeping task 