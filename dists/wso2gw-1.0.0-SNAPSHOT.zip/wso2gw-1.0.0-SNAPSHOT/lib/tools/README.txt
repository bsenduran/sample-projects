CARBON_HOME/lib/tools contains all the libraries necessary to run
carbon provided tools such as jar-to-bundle converter, etc.