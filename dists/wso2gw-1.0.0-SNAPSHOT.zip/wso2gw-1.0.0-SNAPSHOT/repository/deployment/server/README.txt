This directory can be used to deploy all kind of server-side deployable artifacts in Carbon.
