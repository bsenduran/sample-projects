CARBON_HOME/lib contains all the libraries necessary to run Carbon in
standalone mode